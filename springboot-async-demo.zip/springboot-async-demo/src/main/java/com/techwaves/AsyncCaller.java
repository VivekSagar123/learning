package com.techwaves;

import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class AsyncCaller {
	@Autowired
	AsyncMailTrigger asyncMailTriggerObject;

	public void toCall() {
		System.out.println("Calling From rightWayToCall Thread " + Thread.currentThread().getName());
		asyncMailTriggerObject.senMail(populateMap());
	}
	private Map<String, String> populateMap() {
		Map<String, String> mailMap = new HashMap<String, String>();
		mailMap.put("body", "A Ask2Shamik Article");
		return mailMap;
	}
}