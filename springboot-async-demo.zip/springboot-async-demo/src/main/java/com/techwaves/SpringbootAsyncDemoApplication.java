package com.techwaves;

import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class SpringbootAsyncDemoApplication {
	
	@Autowired
	public static AsyncCaller asynCaller;

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		SpringApplication.run(SpringbootAsyncDemoApplication.class, args);
	}

}
