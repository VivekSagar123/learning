package com.techwaves.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.techwaves.dao.UserRepository;
import com.techwaves.model.User;

@Service
public class UserService {

	@Autowired
	UserRepository userRepo;

	public List<User> getUsers(){
		return userRepo.findAll();
	}
	
	public User addUser(User user){
		return userRepo.save(user);
	}
}
